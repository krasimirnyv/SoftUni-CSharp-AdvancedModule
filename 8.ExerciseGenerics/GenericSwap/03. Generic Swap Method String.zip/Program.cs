﻿namespace GenericSwap;

public class Program
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        List<Box<string>> boxes = new List<Box<string>>();
        for (int i = 1; i <= n; i++)
        {
            string text = Console.ReadLine();
            Box<string> box = new Box<string>(text);
            boxes.Add(box);
        }
        
        int[] indeces = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
        Swap(boxes, indeces[0], indeces[1]);
        
        boxes.ForEach(Console.WriteLine);
    }

    static void Swap<TValue>(List<TValue> list, int a, int b)
    {
        (list[a], list[b]) = (list[b], list[a]);
    } 
}
