﻿namespace GenericBox;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        for (int i = 1; i <= n; i++)
        {
            // string text = Console.ReadLine();
            // Box<string> box = new Box<string>(text);
            
            int number = int.Parse(Console.ReadLine());
            Box<int> box = new Box<int>(number);
            Console.WriteLine(box);
        }
    }
}
