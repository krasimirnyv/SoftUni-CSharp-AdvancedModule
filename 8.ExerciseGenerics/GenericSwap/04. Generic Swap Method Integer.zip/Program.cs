﻿namespace GenericSwap;

public class Program
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        List<Box<int>> boxes = new List<Box<int>>();
        for (int i = 1; i <= n; i++)
        {
            int number = int.Parse(Console.ReadLine());
            Box<int> box = new Box<int>(number);
            boxes.Add(box);
        }
        
        int[] indeces = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
        Swap(boxes, indeces[0], indeces[1]);
        
        boxes.ForEach(Console.WriteLine);
    }

    static void Swap<TValue>(List<TValue> list, int a, int b)
    {
        (list[a], list[b]) = (list[b], list[a]);
    } 
}
