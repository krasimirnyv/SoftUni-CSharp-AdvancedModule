namespace Cars;

public class Car
{
    public string Model { get; set; }
    public double FuelAmount { get; set; }
    public double FuelConsumptionPerKm { get; set; }
    public double DistanceTraveled { get; set; }
    
    public Car(string model, double fuelAmount, double fuelConsumptionPerKm)
    {
        this.Model = model;
        this.FuelAmount = fuelAmount;
        this.FuelConsumptionPerKm = fuelConsumptionPerKm;
        this.DistanceTraveled = 0;
    }

    public bool Drive(double distance)
    {
        double fuelNeeded = distance * this.FuelConsumptionPerKm;
        if (fuelNeeded > this.FuelAmount)
            return false;
        
        this.FuelAmount -= fuelNeeded;
        this.DistanceTraveled += distance;
        return true;
    }

    public override string ToString()
    {
        return $"{Model} {FuelAmount:F2} {DistanceTraveled}";
    }
}