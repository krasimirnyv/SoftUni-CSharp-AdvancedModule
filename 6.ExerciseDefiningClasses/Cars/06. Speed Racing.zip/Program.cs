﻿namespace Cars;

class Program
{
    static void Main(string[] args)
    {
        Dictionary<string, Car> cars = new Dictionary<string, Car>();
        
        int lines = int.Parse(Console.ReadLine());
        while (lines-- > 0)
        {
            string[] input = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);

            string model = input[0];
            double fuelAmount = double.Parse(input[1]),
                   fuelConsumptionPerKm = double.Parse(input[2]);

            Car car = new Car(model, fuelAmount, fuelConsumptionPerKm);
            cars.Add(model, car);
        }

        string command = default;
        while ((command = Console.ReadLine()) != "End")
        {
            string[] tokens = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            
            string model = tokens[1];
            double distance = double.Parse(tokens[2]);

            if (!cars[model].Drive(distance))
                Console.WriteLine("Insufficient fuel for the drive");
        }

        foreach (Car car in cars.Values) 
            Console.WriteLine(car);
    }
}