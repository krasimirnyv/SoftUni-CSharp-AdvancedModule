namespace Cars;

public class Engine
{
    public Engine(uint speed, uint power)
    {
        Speed = speed;
        Power = power;
    }

    public uint Speed { get; set; }
    public uint Power { get; set; }
}