﻿namespace Cars;

class Program
{
    static void Main(string[] args)
    {
        List<Car> cars = new List<Car>();
        int lines = int.Parse(Console.ReadLine());
        while (lines-- > 0)
        {
            string[] input = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);
            
            string model = input[0];
            Engine engine = new Engine(speed: uint.Parse(input[1]), power: uint.Parse(input[2]));
            Cargo cargo = new Cargo(weight: uint.Parse(input[3]), type: input[4]);
            
            Tires[] tires = new Tires[4];
            for (int i = 0; i < tires.Length; i++) 
                tires[i] = new Tires(pressure: double.Parse(input[5 + i * 2]), age: uint.Parse(input[6 + i * 2]));

            Car car = new Car(model, engine, cargo, tires);
            cars.Add(car);
        }
        
        Func<Car, bool> condition;
        string command = Console.ReadLine();
        switch (command)
        {
            case "fragile":
                condition = c => c.Cargo.Type == "fragile" && c.Tires.Any(t => t.Pressure < 1);
                break;
            case "flammable":
                condition = c => c.Cargo.Type == "flammable" && c.Engine.Power > 250;
                break;
            default:
                throw new ArgumentException("Invalid command!");
        }

        foreach (Car car in cars.Where(condition))
        {
            Console.WriteLine(car.Model);
        }
    }
}
