﻿namespace DefiningClasses;

public class StartUp
{
    static void Main(string[] args)
    {
        Person p1 = new Person()
        {
            Name = "George",
            Age = 18
        };

        Person p2 = new Person() { Name = "Jose", Age = 43 };
    }
}