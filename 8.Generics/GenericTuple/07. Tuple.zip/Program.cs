﻿namespace GenericTuple;

public class Program
{
    public static void Main(string[] args)
    {
        string[] first = Console.ReadLine().Split();
        MyTuple<string, string> t1 = new MyTuple<string, string>($"{first[0]} {first[1]}", first[2]);
        
        string[] second = Console.ReadLine().Split();
        MyTuple<string, int> t2 = new MyTuple<string, int>(second[0], int.Parse(second[1]));
        
        string[] third = Console.ReadLine().Split();
        MyTuple<int, double> t3 = new MyTuple<int, double>(int.Parse(third[0]), double.Parse(third[1]));

        Console.WriteLine(t1);
        Console.WriteLine(t2);
        Console.WriteLine(t3);
    }
}
