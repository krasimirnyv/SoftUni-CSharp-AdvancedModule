﻿namespace GenericBox;

public class Program
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        List<string> list = new List<string>(capacity: n);
        for (int i = 1; i <= n; i++)
        {
            string line = Console.ReadLine();
            list.Add(line);
        }
        
        string compareValue = Console.ReadLine();
        int count = CountGreaterThan(list, compareValue); 
        Console.WriteLine(count);
    }

    static int CountGreaterThan<TValue>(List<TValue> list, TValue compareValue)
    {
        int count = 0;
        foreach (TValue element in list)
        {
            if (Comparer<TValue>.Default.Compare(element, compareValue) > 0)
                count++;
        }
        
        return count;
    }
}
